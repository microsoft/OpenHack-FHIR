#!/bin/bash

sed -i "s/growth_chart/${CLIENT_ID}/" launch.html
npm start